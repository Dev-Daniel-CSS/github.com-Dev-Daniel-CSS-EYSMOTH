
import React from 'react';
import { ChatMessage, MessageRole } from '../types';

interface MessageItemProps {
  message: ChatMessage;
}

const MessageItem: React.FC<MessageItemProps> = ({ message }) => {
  const isUser = message.role === MessageRole.USER;

  const renderContent = (content: string) => {
    const parts = content.split(/(```[\s\S]*?```)/g);
    
    return parts.map((part, index) => {
      if (part.startsWith('```')) {
        const match = part.match(/```(\w+)?\n?([\s\S]*?)```/);
        const code = match?.[2] || '';
        
        return (
          <div key={index} className="my-3 overflow-hidden rounded-xl border border-slate-200 bg-slate-50">
            <pre className="p-4 text-sm leading-relaxed text-slate-700 overflow-x-auto">
              <code>{code}</code>
            </pre>
          </div>
        );
      }
      
      return (
        <p key={index} className="whitespace-pre-wrap leading-relaxed">
          {part.split(/(\*\*[^*]+\*\*|`[^`]+`)/g).map((subPart, subIndex) => {
            if (subPart.startsWith('**') && subPart.endsWith('**')) {
              return <strong key={subIndex} className="font-bold text-black">{subPart.slice(2, -2)}</strong>;
            }
            if (subPart.startsWith('`') && subPart.endsWith('`')) {
              return <code key={subIndex} className="rounded bg-slate-100 px-1 py-0.5 text-black font-mono text-sm">{subPart.slice(1, -1)}</code>;
            }
            return subPart;
          })}
        </p>
      );
    });
  };

  return (
    <div className={`flex w-full animate-in fade-in slide-in-from-bottom-1 duration-500 ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`group relative flex max-w-[80%] flex-col gap-1.5 ${isUser ? 'items-end' : 'items-start'}`}>
        <div className={`rounded-2xl px-5 py-3.5 ${
          isUser 
          ? 'bg-black text-white shadow-sm' 
          : 'bg-white border border-slate-200 shadow-sm text-slate-800'
        }`}>
          {message.type === 'image' && message.imageUrl ? (
            <div className="space-y-4 py-2">
              <div className="relative overflow-hidden rounded-lg shadow-lg aspect-[3/4] bg-slate-100">
                <img 
                  src={message.imageUrl} 
                  alt="Style Visualization" 
                  className="w-full h-full object-cover transition-transform duration-700 hover:scale-110"
                  loading="lazy"
                />
              </div>
              <p className="text-sm italic opacity-80">{message.content}</p>
            </div>
          ) : (
            <div className="text-[15px]">
               {renderContent(message.content)}
            </div>
          )}
        </div>
        <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest px-1">
          {isUser ? 'Me' : 'ThriftAI'} • {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </span>
      </div>
    </div>
  );
};

export default MessageItem;
