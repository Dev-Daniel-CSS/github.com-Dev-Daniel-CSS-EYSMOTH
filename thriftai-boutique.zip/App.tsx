
import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage, MessageRole, ThriftItem, UserRole, UserProfile, CartItem, PaymentMethod } from './types';
import { generateAIResponse, detectImageIntent } from './services/geminiService';
import MessageItem from './components/MessageItem';
import ChatInput from './components/ChatInput';

const App: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [inventory, setInventory] = useState<ThriftItem[]>([]);
  const [editingItem, setEditingItem] = useState<ThriftItem | null>(null);
  const [role, setRole] = useState<UserRole>(UserRole.UNSET);
  const [userProfile, setUserProfile] = useState<UserProfile>({
    email: '',
    phone: '',
    address: '',
    zipCode: '',
    name: ''
  });
  const [isProfileSubmitted, setIsProfileSubmitted] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  
  // Cart States
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(PaymentMethod.COD);
  const [isOrderPlaced, setIsOrderPlaced] = useState(false);

  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const categories = ['All', 'T-shirt', 'Pants', 'Shorts', 'Outerwear', 'Dresses', 'Vintage'];

  useEffect(() => {
    // Initial mock inventory data
    setInventory([
      { id: '1', title: "Vintage Silk Slip Dress", description: "90s minimalist aesthetic, emerald green, size S.", price: "$45.00", category: "Dresses", imageUrl: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=800&auto=format&fit=crop", status: 'published' },
      { id: '2', title: "Leather Bomber Jacket", description: "Distressed brown leather, oversized fit, unisex.", price: "$85.00", category: "Outerwear", imageUrl: "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800&auto=format&fit=crop", status: 'published' },
      { id: '3', title: "Retro Graphic T-shirt", description: "Soft cotton, 80s band graphic, size M.", price: "$22.00", category: "T-shirt", imageUrl: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800&auto=format&fit=crop", status: 'published' },
      { id: '4', title: "Classic Denim Shorts", description: "High-waisted, frayed hem, Levi's vintage.", price: "$35.00", category: "Shorts", imageUrl: "https://images.unsplash.com/photo-1591195853828-11db59a44f6b?w=800&auto=format&fit=crop", status: 'published' },
      { id: '5', title: "Cargo Work Pants", description: "Khaki durable canvas, multiple pockets, size 32.", price: "$40.00", category: "Pants", imageUrl: "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=800&auto=format&fit=crop", status: 'published' },
      { id: '6', title: "Oversized Flannel Shirt", description: "Checked red and black, grunge style, size L.", price: "$28.00", category: "T-shirt", imageUrl: "https://images.unsplash.com/photo-1589483232748-515c025575ba?w=800&auto=format&fit=crop", status: 'published' },
      { id: '7', title: "Vintage Levi's 501", description: "Classic straight leg, light wash denim, waist 30.", price: "$55.00", category: "Pants", imageUrl: "https://images.unsplash.com/photo-1542272604-787c3835535d?w=800&auto=format&fit=crop", status: 'published' },
      { id: '8', title: "Linen Summer Shorts", description: "Off-white breathable linen, elastic waist, size S.", price: "$30.00", category: "Shorts", imageUrl: "https://images.unsplash.com/photo-1565084888279-aca607ecce0c?w=800&auto=format&fit=crop", status: 'published' },
    ]);
  }, []);

  useEffect(() => {
    if (role === UserRole.SELLER && isProfileSubmitted) {
      const welcome: ChatMessage = {
        id: 'welcome',
        role: MessageRole.ASSISTANT,
        content: `Welcome back, **${userProfile.name || 'Seller'}**. Ready to list? Describe your item or upload a photo!`,
        timestamp: Date.now(),
        type: 'text'
      };
      setMessages([welcome]);
    }
  }, [role, isProfileSubmitted]);

  const handleSendMessage = async (input: string, forceImage: boolean) => {
    const isImage = forceImage || detectImageIntent(input);
    const userMessage: ChatMessage = { id: Date.now().toString(), role: MessageRole.USER, content: input, timestamp: Date.now(), type: 'text' };
    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    try {
      const apiHistory = messages.slice(-6).map(m => ({ role: m.role === MessageRole.USER ? 'user' : 'model', parts: [{ text: m.content }] }));
      const response = await generateAIResponse(input, apiHistory, isImage, 'seller');
      const botMessage: ChatMessage = { id: Date.now().toString(), role: MessageRole.ASSISTANT, content: response.text || (isImage ? "Visualization complete." : ""), timestamp: Date.now(), type: isImage ? 'image' : 'text', imageUrl: response.imageUrl };
      setMessages(prev => [...prev, botMessage]);

      if (response.extractedListing) {
        const newItem: ThriftItem = {
          id: Date.now().toString(),
          title: response.extractedListing.title || "New Item",
          description: response.extractedListing.description || "",
          price: response.extractedListing.price || "$0.00",
          category: response.extractedListing.category || "Uncategorized",
          imageUrl: response.imageUrl || "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=800&auto=format&fit=crop",
          status: 'draft'
        };
        setInventory(prev => [newItem, ...prev]);
      }
    } catch (error) {
      setMessages(prev => [...prev, { id: 'err', role: MessageRole.ASSISTANT, content: "Error in logic. Try again.", timestamp: Date.now(), type: 'text' }]);
    } finally { setIsLoading(false); }
  };

  const deleteItem = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (window.confirm("Permanently remove this listing from your inventory?")) {
      setInventory(prev => prev.filter(item => item.id !== id));
    }
  };

  const addToCart = (e: React.MouseEvent, item: ThriftItem) => {
    e.stopPropagation();
    const newCartItem: CartItem = {
      ...item,
      cartId: Date.now().toString() + Math.random(),
      selected: true
    };
    setCart(prev => [...prev, newCartItem]);
    alert(`${item.title} added to cart!`);
  };

  const removeFromCart = (cartId: string) => {
    setCart(prev => prev.filter(item => item.cartId !== cartId));
  };

  const toggleCartItemSelection = (cartId: string) => {
    setCart(prev => prev.map(item => 
      item.cartId === cartId ? { ...item, selected: !item.selected } : item
    ));
  };

  const calculateTotal = () => {
    const total = cart
      .filter(i => i.selected)
      .reduce((acc, item) => acc + parseFloat(item.price.replace('$', '')), 0);
    return `$${total.toFixed(2)}`;
  };

  const handleCheckout = () => {
    if (cart.filter(i => i.selected).length === 0) {
      alert("Please select at least one item to checkout.");
      return;
    }
    setIsCheckoutOpen(true);
    setIsCartOpen(false);
  };

  const placeOrder = () => {
    setIsOrderPlaced(true);
    setTimeout(() => {
      setCart(prev => prev.filter(i => !i.selected));
      setIsOrderPlaced(false);
      setIsCheckoutOpen(false);
      alert("Order placed successfully! Thank you for shopping with ThriftAI.");
    }, 2000);
  };

  const filteredItems = inventory
    .filter(i => i.status === 'published')
    .filter(i => activeCategory === 'All' || i.category.toLowerCase().includes(activeCategory.toLowerCase()))
    .filter(i => i.title.toLowerCase().includes(searchQuery.toLowerCase()) || i.description.toLowerCase().includes(searchQuery.toLowerCase()));

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProfileSubmitted(true);
  };

  const handleLogout = () => {
    setRole(UserRole.UNSET);
    setIsProfileSubmitted(false);
    setCart([]);
  };

  // --- STEP 1: INITIAL PROFILE COLLECTION ---
  if (!isProfileSubmitted) {
    return (
      <div className="flex min-h-screen w-full items-center justify-center bg-[#fdfcfb] p-6">
        <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl p-10 animate-in slide-in-from-bottom-4 duration-500 border border-slate-50">
          <div className="text-center mb-8">
            <h1 className="serif-font text-4xl font-bold mb-2">ThriftAI</h1>
            <p className="text-slate-400 text-[10px] font-bold uppercase tracking-[0.2em]">Identify yourself to continue</p>
          </div>
          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Full Name</label>
              <input required type="text" placeholder="John Doe" value={userProfile.name} onChange={e => setUserProfile({...userProfile, name: e.target.value})} className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-black transition-all" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Email Address</label>
              <input required type="email" placeholder="john@example.com" value={userProfile.email} onChange={e => setUserProfile({...userProfile, email: e.target.value})} className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-black transition-all" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Phone Number</label>
              <input required type="tel" placeholder="+1 (555) 000-0000" value={userProfile.phone} onChange={e => setUserProfile({...userProfile, phone: e.target.value})} className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-black transition-all" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Street Address</label>
              <input required type="text" placeholder="123 Fashion Ave" value={userProfile.address} onChange={e => setUserProfile({...userProfile, address: e.target.value})} className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-black transition-all" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Zip Code</label>
              <input required type="text" placeholder="90210" value={userProfile.zipCode} onChange={e => setUserProfile({...userProfile, zipCode: e.target.value})} className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-black transition-all" />
            </div>
            <button type="submit" className="w-full bg-black text-white font-bold py-4 rounded-xl hover:opacity-90 active:scale-95 transition-all mt-6 uppercase tracking-widest text-xs shadow-lg shadow-black/10">Continue to Hub</button>
          </form>
        </div>
      </div>
    );
  }

  // --- STEP 2: ROLE SELECTION ---
  if (role === UserRole.UNSET) {
    return (
      <div className="flex min-h-screen w-full items-center justify-center bg-[#fdfcfb] p-6">
        <div className="w-full max-w-4xl space-y-12 text-center animate-in fade-in zoom-in duration-500">
          <div className="space-y-2">
            <h1 className="serif-font text-6xl font-bold tracking-tight text-black">Choose Your Path</h1>
            <p className="text-slate-400 uppercase tracking-[0.4em] font-semibold text-[10px]">Logged in as {userProfile.name}</p>
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            <button 
              onClick={() => setRole(UserRole.SELLER)} 
              className="group relative overflow-hidden rounded-3xl bg-black p-12 text-white shadow-2xl transition-all hover:scale-[1.02] hover:-translate-y-1 text-left"
            >
              <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
                 <svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/></svg>
              </div>
              <h2 className="serif-font text-3xl font-bold mb-4">I'm a Seller</h2>
              <p className="text-slate-400 text-sm mb-8 leading-relaxed">List items in seconds with AI assistance and manage your shop's inventory.</p>
              <span className="font-bold text-[10px] uppercase tracking-widest border-b border-white/20 pb-1 group-hover:border-white transition-all">Go to Seller Studio</span>
            </button>
            <button 
              onClick={() => setRole(UserRole.BUYER)} 
              className="group relative overflow-hidden rounded-3xl bg-white p-12 text-black shadow-xl border border-slate-100 transition-all hover:scale-[1.02] hover:-translate-y-1 text-left"
            >
              <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
                <svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
              </div>
              <h2 className="serif-font text-3xl font-bold mb-4">I'm a Buyer</h2>
              <p className="text-slate-500 text-sm mb-8 leading-relaxed">Explore a curated marketplace of unique thrifted pieces and rare finds.</p>
              <span className="font-bold text-[10px] uppercase tracking-widest border-b border-black/10 pb-1 group-hover:border-black transition-all">Browse Marketplace</span>
            </button>
          </div>
          <button onClick={handleLogout} className="text-slate-400 text-[10px] font-bold uppercase tracking-widest hover:text-red-500 transition-colors">Switch Profile / Log Out</button>
        </div>
      </div>
    );
  }

  // --- BUYER VIEW: SHOPEE STYLE MARKETPLACE ---
  if (role === UserRole.BUYER) {
    return (
      <div className="flex h-screen w-full bg-[#f8f7f5] overflow-hidden flex-col relative">
        {/* Market Header */}
        <header className="bg-white border-b border-slate-100 px-6 py-4 sticky top-0 z-10 shadow-sm">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="flex items-center gap-4 cursor-pointer" onClick={() => setRole(UserRole.UNSET)}>
              <h1 className="serif-font text-3xl font-black text-black tracking-tighter">ThriftAI</h1>
            </div>
            
            <div className="flex-1 max-w-2xl w-full relative">
              <input 
                type="text" 
                placeholder="Search for pants, t-shirts, vintage shorts..." 
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full bg-slate-100 border-none rounded-2xl px-6 py-3.5 pl-12 outline-none focus:bg-white focus:ring-2 focus:ring-black transition-all font-medium text-sm"
              />
              <svg className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
            </div>

            <div className="flex items-center gap-6">
              <div className="hidden sm:flex flex-col items-end">
                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Delivery to</span>
                <span className="text-[11px] font-bold text-black">{userProfile.zipCode}</span>
              </div>
              <button onClick={handleLogout} className="text-[10px] font-bold text-red-500 uppercase tracking-widest hover:underline">Log Out</button>
              <button 
                onClick={() => setIsCartOpen(true)}
                className="relative p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
                {cart.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-600 text-white text-[8px] font-bold h-4 w-4 rounded-full flex items-center justify-center animate-bounce">
                    {cart.length}
                  </span>
                )}
              </button>
            </div>
          </div>
        </header>

        {/* Categories Scroller */}
        <div className="bg-white px-6 py-3 border-b border-slate-100 flex gap-3 overflow-x-auto no-scrollbar scroll-smooth">
          {categories.map(cat => (
            <button 
              key={cat} 
              onClick={() => setActiveCategory(cat)}
              className={`px-5 py-2 rounded-xl text-[10px] font-bold whitespace-nowrap transition-all uppercase tracking-widest border ${activeCategory === cat ? 'bg-black text-white border-black shadow-lg shadow-black/10' : 'bg-white text-slate-500 border-slate-100 hover:border-slate-300'}`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Product Grid Feed */}
        <main className="flex-1 overflow-y-auto p-6 md:p-10 scroll-smooth">
          <div className="max-w-7xl mx-auto">
            <div className="mb-8 flex items-baseline justify-between">
              <h2 className="serif-font text-4xl font-bold">{activeCategory === 'All' ? 'New Arrivals' : `${activeCategory} Collection`}</h2>
              <span className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">{filteredItems.length} styles available</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6 md:gap-8">
              {filteredItems.map(item => (
                <div key={item.id} className="group bg-white rounded-[2rem] overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500 border border-slate-100 flex flex-col cursor-pointer">
                  <div className="aspect-[3/4] overflow-hidden relative">
                    <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" />
                    <div className="absolute top-4 right-4 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                      <button className="p-2.5 bg-white/90 backdrop-blur rounded-full shadow-lg hover:bg-white transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="text-slate-800"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
                      </button>
                    </div>
                  </div>
                  <div className="p-5 flex flex-col flex-1">
                    <span className="text-[9px] font-black text-slate-300 uppercase tracking-widest mb-1">{item.category}</span>
                    <h3 className="font-bold text-slate-900 text-sm line-clamp-1 mb-3 group-hover:text-black transition-colors">{item.title}</h3>
                    <div className="mt-auto pt-4 border-t border-slate-50 flex items-center justify-between">
                      <span className="text-xl font-black text-black">{item.price}</span>
                      <button 
                        onClick={(e) => addToCart(e, item)}
                        className="bg-black text-white text-[9px] font-bold px-4 py-2 rounded-xl uppercase tracking-widest hover:bg-slate-800 transition-all active:scale-95 shadow-md shadow-black/10"
                      >
                        Add to Cart
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {filteredItems.length === 0 && (
              <div className="py-32 text-center animate-in fade-in duration-500">
                <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6">
                   <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                </div>
                <h3 className="serif-font text-2xl font-bold mb-2">No items found</h3>
                <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">Try adjusting your search or category</p>
              </div>
            )}
          </div>
        </main>

        {/* --- SHOPEE STYLE CART MODAL --- */}
        {isCartOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-end bg-black/40 backdrop-blur-sm p-4">
            <div className="bg-white w-full max-w-md h-full rounded-3xl shadow-2xl flex flex-col animate-in slide-in-from-right duration-300">
              <div className="p-6 border-b border-slate-100 flex justify-between items-center">
                <div className="flex items-center gap-3">
                   <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
                   <h2 className="serif-font text-2xl font-bold">Your Cart</h2>
                </div>
                <button onClick={() => setIsCartOpen(false)} className="p-2 hover:bg-slate-50 rounded-full transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {cart.length > 0 ? (
                  cart.map(item => (
                    <div key={item.cartId} className="flex gap-4 items-center bg-slate-50 p-4 rounded-2xl group border border-transparent hover:border-slate-200 transition-all">
                      <input 
                        type="checkbox" 
                        checked={item.selected} 
                        onChange={() => toggleCartItemSelection(item.cartId)}
                        className="h-5 w-5 rounded-md border-slate-300 text-black focus:ring-black cursor-pointer"
                      />
                      <div className="h-20 w-16 bg-white rounded-lg overflow-hidden shrink-0 border border-slate-100">
                         <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-bold text-sm text-slate-800 truncate">{item.title}</h4>
                        <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">{item.category}</p>
                        <p className="text-sm font-black mt-1 text-black">{item.price}</p>
                      </div>
                      <button 
                        onClick={() => removeFromCart(item.cartId)}
                        className="p-2 text-slate-300 hover:text-red-500 transition-colors"
                      >
                         <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
                      </button>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-20">
                     <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
                     </div>
                     <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">Your cart is empty</p>
                  </div>
                )}
              </div>

              {cart.length > 0 && (
                <div className="p-6 border-t border-slate-100 bg-white">
                  <div className="flex items-center justify-between mb-6">
                    <span className="text-sm font-bold text-slate-400 uppercase tracking-widest">Estimated Total</span>
                    <span className="text-2xl font-black">{calculateTotal()}</span>
                  </div>
                  <button 
                    onClick={handleCheckout}
                    className="w-full bg-black text-white font-bold py-4 rounded-2xl hover:bg-slate-800 transition-all shadow-xl shadow-black/10 active:scale-95"
                  >
                    Check Out ({cart.filter(i => i.selected).length})
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* --- SHOPEE STYLE CHECKOUT MODAL --- */}
        {isCheckoutOpen && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/60 backdrop-blur-md p-4">
            <div className="bg-white w-full max-w-xl rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-300 max-h-[90vh]">
               <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-slate-50/50">
                  <div>
                    <h2 className="serif-font text-3xl font-bold">Checkout</h2>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Order Summary & Payment</p>
                  </div>
                  <button onClick={() => setIsCheckoutOpen(false)} className="p-2 hover:bg-white rounded-full transition-colors border border-transparent hover:border-slate-100">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                  </button>
               </div>

               <div className="flex-1 overflow-y-auto p-8 space-y-8">
                  {/* Shipping Info */}
                  <section>
                    <div className="flex items-center gap-2 mb-4">
                       <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-red-500"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                       <h3 className="text-xs font-bold uppercase tracking-widest text-slate-800">Shipping Address</h3>
                    </div>
                    <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100">
                       <p className="font-bold text-sm text-black mb-1">{userProfile.name}</p>
                       <p className="text-xs text-slate-500 leading-relaxed mb-1">{userProfile.phone}</p>
                       <p className="text-xs text-slate-500 leading-relaxed">{userProfile.address}, {userProfile.zipCode}</p>
                    </div>
                  </section>

                  {/* Items List */}
                  <section>
                    <h3 className="text-xs font-bold uppercase tracking-widest text-slate-800 mb-4 ml-1">Order Items</h3>
                    <div className="space-y-3">
                      {cart.filter(i => i.selected).map(item => (
                        <div key={item.cartId} className="flex justify-between items-center text-sm">
                           <span className="text-slate-600 line-clamp-1 flex-1 pr-4">{item.title}</span>
                           <span className="font-black text-black">{item.price}</span>
                        </div>
                      ))}
                    </div>
                  </section>

                  {/* Payment Method */}
                  <section>
                    <h3 className="text-xs font-bold uppercase tracking-widest text-slate-800 mb-4 ml-1">Payment Method</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                       <button 
                        onClick={() => setPaymentMethod(PaymentMethod.COD)}
                        className={`p-4 rounded-2xl border-2 flex flex-col gap-2 transition-all text-left ${paymentMethod === PaymentMethod.COD ? 'border-black bg-black text-white' : 'border-slate-100 hover:border-slate-200'}`}
                       >
                          <span className="text-xs font-bold uppercase tracking-widest">COD</span>
                          <span className={`text-[10px] ${paymentMethod === PaymentMethod.COD ? 'text-slate-400' : 'text-slate-400'}`}>Cash on Delivery</span>
                       </button>
                       <button 
                        onClick={() => setPaymentMethod(PaymentMethod.GCASH)}
                        className={`p-4 rounded-2xl border-2 flex flex-col gap-2 transition-all text-left ${paymentMethod === PaymentMethod.GCASH ? 'border-blue-500 bg-blue-500 text-white' : 'border-slate-100 hover:border-slate-200'}`}
                       >
                          <span className="text-xs font-bold uppercase tracking-widest">GCash</span>
                          <span className={`text-[10px] ${paymentMethod === PaymentMethod.GCASH ? 'text-blue-100' : 'text-slate-400'}`}>E-Wallet Transfer</span>
                       </button>
                    </div>
                  </section>
               </div>

               <div className="p-8 border-t border-slate-50 bg-slate-50/30">
                  <div className="flex justify-between items-end mb-6">
                     <div>
                       <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Grand Total</p>
                       <p className="text-3xl font-black text-black">{calculateTotal()}</p>
                     </div>
                     <div className="text-right">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Standard Shipping</p>
                        <p className="text-xs font-bold text-green-600">FREE</p>
                     </div>
                  </div>
                  <button 
                    onClick={placeOrder}
                    disabled={isOrderPlaced}
                    className="w-full h-16 bg-black text-white font-bold rounded-2xl active:scale-95 transition-all flex items-center justify-center gap-3 disabled:opacity-50"
                  >
                    {isOrderPlaced ? (
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
                        <span>Processing...</span>
                      </div>
                    ) : (
                      <>
                        <span>Place Order</span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                      </>
                    )}
                  </button>
               </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // --- SELLER VIEW: AI STUDIO (Existing) ---
  return (
    <div className="flex h-screen w-full bg-[#fdfcfb] overflow-hidden flex-col md:flex-row">
      <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={(e) => {
         const file = e.target.files?.[0];
         if (!file) return;
         const reader = new FileReader();
         reader.onload = (event) => {
           const imageUrl = event.target?.result as string;
           const newItem: ThriftItem = { id: Date.now().toString(), title: "Draft Item", description: "Listing started from photo.", price: "$0.00", category: "Uncategorized", imageUrl: imageUrl, status: 'draft' };
           setInventory(prev => [newItem, ...prev]);
           setEditingItem(newItem);
         };
         reader.readAsDataURL(file);
      }} />

      <aside className="w-full md:w-[400px] border-r border-slate-100 flex flex-col bg-white">
        <div className="p-6 border-b border-slate-100">
          <div className="flex items-center justify-between mb-6">
            <h1 className="serif-font text-2xl font-bold tracking-tight">Seller Studio</h1>
            <button onClick={() => fileInputRef.current?.click()} className="p-2 rounded-full bg-black text-white hover:bg-slate-800 transition-all flex items-center gap-2 px-4 py-2 shadow-lg shadow-black/10">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
              <span className="text-xs font-bold uppercase tracking-widest">List Item</span>
            </button>
          </div>
          <div className="flex items-center justify-between">
            <button className="text-xs font-bold border-b-2 border-black pb-1">Inventory ({inventory.length})</button>
            <button onClick={handleLogout} className="text-[10px] font-bold text-red-500 uppercase tracking-widest hover:underline">Exit Studio</button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50/50">
          {inventory.map((item) => (
            <div key={item.id} className="group relative bg-white rounded-2xl overflow-hidden border border-slate-100 shadow-sm hover:shadow-md transition-all">
              <div className="aspect-[4/5] bg-slate-100 relative">
                <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover" />
                <div className={`absolute top-3 right-3 px-2 py-1 rounded text-[10px] font-bold uppercase tracking-widest border ${item.status === 'published' ? 'bg-green-500 text-white border-green-600' : 'bg-white/90 text-slate-600 border-slate-200'}`}>{item.status}</div>
                <button 
                  onClick={(e) => deleteItem(e, item.id)} 
                  className="absolute bottom-3 right-3 p-2 bg-white/90 text-red-500 rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-sm z-10"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
                </button>
              </div>
              <div className="p-4">
                <h3 className="font-bold text-slate-800 text-sm line-clamp-1">{item.title} — {item.price}</h3>
                <div className="mt-3 flex gap-2">
                  <button onClick={() => setEditingItem(item)} className="flex-1 text-[10px] font-bold py-2 bg-slate-100 rounded-lg hover:bg-slate-200 uppercase tracking-widest">Edit</button>
                  <button onClick={() => setInventory(prev => prev.map(i => i.id === item.id ? {...i, status: i.status === 'draft' ? 'published' : 'draft'} : i))} className={`flex-1 text-[10px] font-bold py-2 rounded-lg transition-all uppercase tracking-widest ${item.status === 'published' ? 'bg-slate-800 text-white' : 'bg-black text-white'}`}>{item.status === 'published' ? 'Unlist' : 'List'}</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </aside>

      <main className="flex-1 flex flex-col bg-white">
        <header className="px-8 py-6 flex items-center justify-between border-b border-slate-100">
          <div className="flex items-center gap-4">
            <div className="h-2 w-2 rounded-full bg-black animate-pulse"></div>
            <span className="text-sm font-bold tracking-widest uppercase">Listing Assistant</span>
          </div>
          <div className="flex items-baseline gap-2">
             <span className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">Seller:</span>
             <span className="text-[10px] font-bold text-slate-800 uppercase tracking-widest">{userProfile.name}</span>
          </div>
        </header>
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-8">
          <div className="mx-auto max-w-3xl space-y-10 pb-10">
            {messages.map((msg) => (
              <MessageItem key={msg.id} message={msg} />
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="px-5 py-4 bg-slate-50 rounded-2xl border border-slate-100 flex gap-2 items-center">
                  <div className="h-1.5 w-1.5 bg-slate-400 rounded-full animate-bounce" />
                  <div className="h-1.5 w-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                  <div className="h-1.5 w-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.4s]" />
                </div>
              </div>
            )}
          </div>
        </div>
        <ChatInput onSendMessage={handleSendMessage} disabled={isLoading} />
      </main>

      {/* Edit Item Modal */}
      {editingItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h2 className="serif-font text-xl font-bold">Edit Item</h2>
              <button onClick={() => setEditingItem(null)} className="text-slate-400 hover:text-black transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
              </button>
            </div>
            <form 
              onSubmit={(e) => { 
                e.preventDefault(); 
                setInventory(prev => prev.map(i => i.id === editingItem.id ? editingItem : i)); 
                setEditingItem(null); 
              }} 
              className="p-6 space-y-4 overflow-y-auto"
            >
              <div className="relative aspect-[4/5] bg-slate-100 rounded-2xl overflow-hidden group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                <img src={editingItem.imageUrl} alt="Preview" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white text-[10px] font-bold uppercase tracking-widest">Change Photo</div>
              </div>
              <input type="text" value={editingItem.title} onChange={e => setEditingItem({...editingItem, title: e.target.value})} className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 outline-none focus:ring-1 focus:ring-black" placeholder="Item Name" />
              <div className="grid grid-cols-2 gap-4">
                <input type="text" value={editingItem.price} onChange={e => setEditingItem({...editingItem, price: e.target.value})} className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 outline-none" placeholder="Price" />
                <input type="text" value={editingItem.category} onChange={e => setEditingItem({...editingItem, category: e.target.value})} className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 outline-none" placeholder="Category" />
              </div>
              <textarea rows={3} value={editingItem.description} onChange={e => setEditingItem({...editingItem, description: e.target.value})} className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 outline-none resize-none text-sm" placeholder="Description" />
              <button type="submit" className="w-full bg-black text-white font-bold py-4 rounded-xl active:scale-95 transition-all">Update Listing</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
