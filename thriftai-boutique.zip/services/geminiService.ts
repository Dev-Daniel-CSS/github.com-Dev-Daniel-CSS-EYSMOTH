
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const API_KEY = process.env.API_KEY || '';

export const generateAIResponse = async (
  prompt: string, 
  history: { role: string; parts: { text: string }[] }[] = [],
  isImageRequest: boolean = false,
  userRole: 'seller' | 'buyer' = 'seller'
): Promise<{ text?: string; imageUrl?: string; extractedListing?: any }> => {
  const ai = new GoogleGenAI({ apiKey: API_KEY });

  if (isImageRequest) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [{ text: `A high-end professional clothing photography, studio lighting. ${userRole === 'seller' ? 'Product shot for listing: ' : 'Fashion lifestyle look: '} ${prompt}` }]
        },
        config: {
          imageConfig: {
            aspectRatio: "3:4"
          }
        }
      });

      let imageUrl: string | undefined;
      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          imageUrl = `data:image/png;base64,${part.inlineData.data}`;
          break;
        }
      }

      return { imageUrl, text: response.text };
    } catch (error) {
      console.error("Visual generation failed:", error);
      throw error;
    }
  } else {
    const systemInstruction = userRole === 'seller' 
      ? `You are ThriftAI, an expert fashion reseller. Help users sell thrifted clothes.
         - Offer pricing advice and catchy SEO descriptions.
         - If creating a listing, ALWAYS end with:
           [LISTING_DATA]
           {
             "title": "Item Title",
             "price": "$0.00",
             "category": "Category",
             "description": "Short summary"
           }
           [/LISTING_DATA]
         - Be stylish and professional.`
      : `You are ThriftAI, a luxury personal shopper and style consultant. Help users find their style and shop the marketplace.
         - Suggest outfit combinations based on trends.
         - Help them decide what to buy.
         - Be encouraging, chic, and trend-aware.
         - Focus on finding the perfect piece for their wardrobe.`;

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: [...history, { role: 'user', parts: [{ text: prompt }] }],
        config: {
          systemInstruction,
          thinkingConfig: { thinkingBudget: 16000 }
        }
      });

      const text = response.text || '';
      let extractedListing = null;
      
      if (userRole === 'seller') {
        const match = text.match(/\[LISTING_DATA\]([\s\S]*?)\[\/LISTING_DATA\]/);
        if (match) {
          try {
            extractedListing = JSON.parse(match[1].trim());
          } catch (e) {
            console.error("Failed to parse listing data", e);
          }
        }
      }

      return { 
        text: text.replace(/\[LISTING_DATA\][\s\S]*?\[\/LISTING_DATA\]/, '').trim(), 
        extractedListing 
      };
    } catch (error) {
      console.error("AI response failed:", error);
      throw error;
    }
  }
};

export const detectImageIntent = (prompt: string): boolean => {
  const keywords = ['generate image', 'show me', 'visualize', 'mockup', 'photo of', 'outfit idea'];
  return keywords.some(keyword => prompt.toLowerCase().includes(keyword));
};
